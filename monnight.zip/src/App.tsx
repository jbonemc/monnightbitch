import React, { useState } from 'react';
import { Calendar, Clock, Users, UserMinus, Settings, CreditCard } from 'lucide-react';
import PlayerList from './components/PlayerList';
import AdminPanel from './components/AdminPanel';
import { Player, GameDetails } from './types';

function App() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [newPlayer, setNewPlayer] = useState('');
  const [showAdmin, setShowAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [gameDetails, setGameDetails] = useState<GameDetails>({
    date: '',
    time: '',
    revolutLink: ''
  });

  const handleAddPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlayer.trim()) return;

    const player: Player = {
      id: Date.now(),
      name: newPlayer.trim(),
      timestamp: new Date().toISOString(), // Store as ISO string instead of Date object
    };

    setPlayers([...players, player]);
    setNewPlayer('');
  };

  const handleSubOut = (playerId: number) => {
    setPlayers(players.filter(player => player.id !== playerId));
  };

  const handleAdminAccess = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'f00tball') {
      setShowAdmin(true);
      setShowPasswordModal(false);
      setPasswordError(false);
      setAdminPassword('');
    } else {
      setPasswordError(true);
    }
  };

  const toggleAdminPanel = () => {
    if (showAdmin) {
      setShowAdmin(false);
    } else {
      setShowPasswordModal(true);
    }
  };

  const mainPlayers = players.slice(0, 14);
  const waitlist = players.slice(14);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="max-w-4xl mx-auto p-6">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Football Game Roster</h1>
          {gameDetails.date && gameDetails.time && (
            <div className="flex items-center justify-center gap-6 text-gray-600 flex-wrap">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{gameDetails.date}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span>{gameDetails.time}</span>
              </div>
              {gameDetails.revolutLink && (
                <a
                  href={gameDetails.revolutLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-blue-600 hover:text-blue-800"
                >
                  <CreditCard className="w-5 h-5" />
                  <span>Pay with Revolut</span>
                </a>
              )}
            </div>
          )}
        </header>

        <form onSubmit={handleAddPlayer} className="mb-8">
          <div className="flex gap-4">
            <input
              type="text"
              value={newPlayer}
              onChange={(e) => setNewPlayer(e.target.value)}
              placeholder="Enter player name"
              className="flex-1 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Add Player
            </button>
          </div>
        </form>

        <div className="space-y-8">
          <section>
            <div className="flex items-center gap-2 mb-4">
              <Users className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-semibold text-gray-800">Main Squad ({mainPlayers.length}/14)</h2>
            </div>
            <PlayerList players={mainPlayers} onSubOut={handleSubOut} />
          </section>

          {waitlist.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-4">
                <UserMinus className="w-6 h-6 text-orange-600" />
                <h2 className="text-2xl font-semibold text-gray-800">Waitlist ({waitlist.length})</h2>
              </div>
              <PlayerList players={waitlist} onSubOut={handleSubOut} />
            </section>
          )}
        </div>

        <div className="mt-8 text-center">
          <button
            onClick={toggleAdminPanel}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <Settings className="w-5 h-5" />
            {showAdmin ? 'Hide Admin Panel' : 'Show Admin Panel'}
          </button>
        </div>

        {showPasswordModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full">
              <h3 className="text-xl font-semibold mb-4">Admin Access</h3>
              <form onSubmit={handleAdminAccess}>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="Enter admin password"
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                />
                {passwordError && (
                  <p className="text-red-500 text-sm mb-2">Incorrect password</p>
                )}
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowPasswordModal(false);
                      setPasswordError(false);
                      setAdminPassword('');
                    }}
                    className="px-4 py-2 text-gray-600 hover:text-gray-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showAdmin && (
          <AdminPanel gameDetails={gameDetails} setGameDetails={setGameDetails} />
        )}
      </div>
    </div>
  );
}

export default App;