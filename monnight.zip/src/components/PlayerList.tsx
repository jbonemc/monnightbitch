import React from 'react';
import { UserMinus } from 'lucide-react';
import { Player } from '../types';

interface PlayerListProps {
  players: Player[];
  onSubOut: (id: number) => void;
}

function PlayerList({ players, onSubOut }: PlayerListProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {players.length === 0 ? (
        <p className="p-4 text-gray-500 text-center">No players yet</p>
      ) : (
        <ul className="divide-y divide-gray-200">
          {players.map((player) => (
            <li key={player.id} className="flex items-center justify-between p-4 hover:bg-gray-50">
              <div>
                <h3 className="font-medium text-gray-800">{player.name}</h3>
                <p className="text-sm text-gray-500">
                  Joined: {new Date(player.timestamp).toLocaleTimeString()}
                </p>
              </div>
              <button
                onClick={() => onSubOut(player.id)}
                className="inline-flex items-center gap-2 px-3 py-1 bg-red-100 text-red-700 rounded-full hover:bg-red-200 transition-colors"
              >
                <UserMinus className="w-4 h-4" />
                Sub Out
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default PlayerList;